import React from 'react'

function BuyLaptop() {
  return (
    <div>
      
    </div>
  )
}

export default BuyLaptop
