import React from 'react'

function BuyPhone() {
  return (
    <div>
      
    </div>
  )
}

export default BuyPhone
